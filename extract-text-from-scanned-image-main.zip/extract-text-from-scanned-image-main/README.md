# Extract text from image
Simply gives your image. I will give you the text which is present inside image
